package com.uas.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;
import com.uas.dao.IProgramDAO;


@Service
public class ProgamServiceImplementation implements IProgramService {

	@Autowired
	private IProgramDAO ipd;
	@Override
	public String addProgramDetails(ProgramBean pb) {
		
		return ipd.addProgramDetails(pb);
	}
	@Override
	public int deleteProgramDetails(String deleteProgramName) {
		return ipd.deleteProgramDetails(deleteProgramName);
	}
	@Override
	public ArrayList<ProgramBean> viewAllProgramDetails() {
		
		return ipd.viewAllProgramDetails();
	}
	@Override
	public ProgramBean updateProgramDetails(String programName) {
		return ipd.updateprogramDetails(programName);
	}
	@Override
	public String updateNewProgramDetails(ProgramBean upbo) {
		return ipd.updateNewProgramDetails(upbo);
	}


}
